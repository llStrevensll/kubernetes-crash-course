# Installation using Ansible

Please follow the installation instructions from [istio.io](https://preliminary.istio.io/docs/setup/kubernetes/ansible-install.html).
